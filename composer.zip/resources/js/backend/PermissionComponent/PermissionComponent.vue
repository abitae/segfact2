<template>
  <div>

  </div>
</template>

<script type="text/javascript" src="./PermissionComponent.js"></script>

<template>
  <div class="col-12 mt-3 wihtout-result">
    <img :src="`${END_POINT}/backend/assets/images/stickers/box-empty.png`" alt="Imagen de caja vacía">
    <h6 class="wihtout-result-title">Sin resultados</h6>
  </div>
</template>

<template>
  <div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <div class="card-title select-none">
              <h5 class="color-customized">Nueva cotización</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script src="./QuotateComponent.js"></script>



<?php $__env->startSection('title'); ?>
  Bancos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-title'); ?>
  <div class="row">
    <div class="col-12">
      <div class="page-title-box">
        <div class="page-title">
          <h4 class="mb-0 font-size-18">Lista de bancos</h4>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript: void(0);">Full tecnología</a></li>
            <li class="breadcrumb-item"><a href="javascript: void(0);">Administrar</a></li>
            <li class="breadcrumb-item active select-none">Bancos</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-content-wrapper">
    <bank-component
      can-view="<?php echo e(auth()->user()->can('view banks')); ?>"
      can-create="<?php echo e(auth()->user()->can('create bank')); ?>"
      can-edit="<?php echo e(auth()->user()->can('edit bank')); ?>"
      can-update-status="<?php echo e(auth()->user()->can('update status bank')); ?>"
    ></bank-component>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\proyectos\segfact2\resources\views/backend/banks.blade.php ENDPATH**/ ?>
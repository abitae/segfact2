<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Sistema')); ?></title>
    <meta name="end-point" content="http://quotationtracking.test/">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    
    <meta name="theme-color" content="#1B82EC">
    <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>">
    <link href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css"/>
    <style>
      .cursor-pointer {
        cursor: pointer;
      }
      .select-none {
        user-select: none;
      }
    </style>
  </head>
  <body data-topbar="colored">
    <div class="account-pages"></div>
      <div class="wrapper-page" id="app">
        <div class="card">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="text-center">
          
          <p class="text-muted"> © <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> Full Tecnología</p>
        </div>

      </div>

      <div class="rightbar-overlay"></div>
      <script src="<?php echo e(asset('backend/assets/libs/jquery/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('backend/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('backend/assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
      <script src="<?php echo e(asset('backend/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
      <script src="<?php echo e(asset('backend/assets/libs/node-waves/waves.min.js')); ?>"></script>
      <script src="<?php echo e(asset('backend/assets/libs/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
      <script src="<?php echo e(asset('backend/assets/js/app.js')); ?>"></script>

  </body>
</html>
<?php /**PATH F:\proyectos\segfact2\resources\views/layouts/app.blade.php ENDPATH**/ ?>
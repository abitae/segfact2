<div id="sidebar-menu">
  <ul class="metismenu list-unstyled" id="side-menu">
    <li class="menu-title text-center fw-bolder"> [ <?php echo e(auth()->user()->nickName); ?> ] </li>
    <li class="menu-title">Principal</li>
    <li>
      <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
        <i class="mdi mdi-home"></i>
        <span>Inicio</span>
      </a>
    </li>
    <?php if(auth()->user()->getAllPermissions()->count()): ?>
      <li class="menu-title text-uppercase">Administrar</li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view banks')): ?>
      <li>
        <a href="<?php echo e(route('banks')); ?>" class="waves-effect">
          <i class="fas fa-money-check"></i>
          <span>Bancos</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view client')): ?>
      <li>
        <a href="<?php echo e(route('customers')); ?>" class="waves-effect">
          <i class="fas fa-users"></i>
          <span>Clientes</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view contacts')): ?>
      <li>
        <a href="<?php echo e(route('contacts')); ?>" class="waves-effect">
          <i class="far fa-address-book"></i>
          <span>Contactos</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view enterprises')): ?>
      <li>
        <a href="<?php echo e(route('enterprises')); ?>" class="waves-effect">
          <i class="far fa-building"></i>
          <span>Empresa</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view pucharses')): ?>
      <li>
        <a href="<?php echo e(route('shoppingManagement')); ?>" class="waves-effect">
          <i class="fas fa-cash-register"></i>
          <span>Gestión de compras</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view sales')): ?>
      <li>
        <a href="<?php echo e(route('salesManagement')); ?>" class="waves-effect">
          <i class="fab fa-shopify"></i>
          <span>Gestión de ventas</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view licenses')): ?>
      <li>
        <a href="<?php echo e(route('licenses')); ?>" class="waves-effect">
          <i class="fas fa-compact-disc"></i>
          <span>Seguimiento licencias</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view suppliers')): ?>
      <li>
        <a href="<?php echo e(route('suppliers')); ?>" class="waves-effect">
          <i class="fas fa-people-carry"></i>
          <span>Proveedores</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view roles')): ?>
      <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect" aria-expanded="true">
          <i class="fas fa-users-cog"></i>
          <span>Config. permisos</span>
        </a>
        <ul class="sub-menu" aria-expanded="true">
          <li><a href="<?php echo e(route('roles')); ?>">Roles</a></li>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update roles')): ?>
            <li><a href="<?php echo e(route('assing-permission')); ?>">Asignar permisos</a></li>
          <?php endif; ?>
        </ul>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view invoice tracking')): ?>
      <li>
        <a href="<?php echo e(route('trackingOfReceipts')); ?>" class="waves-effect">
          <i class="fas fa-search-location"></i>
          <span>Seguimiento Fact.</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view series')): ?>
      <li>
        <a href="<?php echo e(route('series')); ?>" class="waves-effect">
          <i class="fas fa-barcode"></i>
          <span>Series</span>
        </a>
      </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
      <li>
        <a href="<?php echo e(route('users')); ?>" class="waves-effect">
          <i class="fas fa-users"></i>
          <span>Usuarios</span>
        </a>
      </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
      <li>
        <a href="<?php echo e(route('mycompany')); ?>" class="waves-effect">
          <i class="fas fa-users"></i>
          <span>MyCompany</span>
        </a>
      </li>
    <?php endif; ?>

  </ul>
</div>
<?php /**PATH F:\proyectos\segfact2\resources\views/backend/layout/sidebar.blade.php ENDPATH**/ ?>
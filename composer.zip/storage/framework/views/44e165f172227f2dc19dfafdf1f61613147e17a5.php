

<?php $__env->startSection('title'); ?>
    Seg. Licencias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-title'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title">
                    <h4 class="mb-0 font-size-18">Seguimiento licencias</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Full tecnología</a></li>
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Administrar</a></li>
                        <li class="breadcrumb-item active select-none">Licencias</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content-wrapper">
        <div class="row">
            <div class="col-12 col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <div class="col-12 text-center">
                            <h5 class="fw-bold">ESTADOS DE EXPIRACIÓN EN LICENCIAS MYCOMPANY</h5>
                        </div>
                        <div class="col-sm-12 text-center">
                            <div class="color-description bg-toinstall">
                                <p> <i class="far fa-square icon-color-toinstall"></i>NUEVO</p>
                            </div>
                            <div class="color-description bg-installed">
                                <p> <i class="fas fa-square icon-color-installed"></i>PRODUCT </p>
                            </div>
                            <div class="color-description bg-byExpire">
                                <p> <i class="fas fa-square icon-color-byExpire"></i>PRUEBA</p>
                            </div>
                            <div class="color-description bg-expired">
                                <p> <i class="fas fa-square icon-color-expired"></i>EXPIRADO</p>
                            </div>
                        </div>
                        <hr>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-company')->html();
} elseif ($_instance->childHasBeenRendered('O8kuAF9')) {
    $componentId = $_instance->getRenderedChildComponentId('O8kuAF9');
    $componentTag = $_instance->getRenderedChildComponentTagName('O8kuAF9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O8kuAF9');
} else {
    $response = \Livewire\Livewire::mount('my-company');
    $html = $response->html();
    $_instance->logRenderedChild('O8kuAF9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\proyectos\segfact2\resources\views/backend/my-company.blade.php ENDPATH**/ ?>
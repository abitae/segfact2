<?php return array (
  'my-company' => 'App\\Http\\Livewire\\MyCompany',
  'my-company-new' => 'App\\Http\\Livewire\\MyCompanyNew',
);